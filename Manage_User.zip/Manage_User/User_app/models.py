from django.db import models

# Create your models here.
class User(models.Model):
    STATUS= [
        ("Active","Active"),
        ("NonActive","NonActive"),
        
        
    ]
    
    FirstName=models.CharField(max_length=100)
    LastName=models.CharField(max_length=100)
    UserEmail=models.EmailField(max_length=200)
    Password=models.CharField(max_length=100)
    MobileNo=models.CharField(max_length=10)
    Designation=models.CharField(max_length=100)
    Status=models.CharField(max_length=100, choices=STATUS)
    
    def __str__(self):
        return self.FirstName
    
    class Meta():
        db_table='user_tbl'
         
    
    