from django.urls import path
from User_app import views

urlpatterns = [
    path('addviewUser/', views.UserListView),
    path('deleteupdateUser/<int:pk>/', views.UserDetailView)
]
