from django.shortcuts import render
from .models import User
from django.http import JsonResponse
from .serializers import UserSerializer
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.http.response import JsonResponse

# Create your views here.
  # FLOOR API
  
@api_view(['GET' , 'POST'])
def UserListView(request):
    if request.method == 'GET':
        users = User.objects.all()
        serializer = UserSerializer(users, many=True)
        return Response({"data":"true", "status_code":200,"message":"Users List", "response":serializer.data})
    
    elif request.method == 'POST':
        serializer = UserSerializer(data = request.data)
        if serializer.is_valid():
            #print(serializer.data)
            return Response({"data":"true","status_code":200,"message":"User added successfully","response":serializer.data})
            #return JsonResponse(serializer.data)
        else:
            return JsonResponse(serializer.errors)
    
    
@api_view(['DELETE' , 'GET' , 'PUT'])
def UserDetailView(request , pk):

    try:
        users=User.objects.get(pk=pk)
    except User.DoesNotExist:
        return Response(status=404)

    if request.method == 'DELETE':
        users.delete()
        return Response({"data":"true","status_code":200,"message":"User deleted successfully"})
        
    elif request.method == 'GET':
        serializer = UserSerializer(users)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = UserSerializer(users, data = request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({"data":"true","status_code":200,"data":"User Updated successfully","response":serializer.data})
        else:
            return Response(serializer.errors)
