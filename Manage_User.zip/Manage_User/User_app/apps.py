from django.apps import AppConfig


class UserAppConfig(AppConfig):
    name = 'User_app'
